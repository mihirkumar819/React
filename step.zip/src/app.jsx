import { Component } from "react";
import PowerClick from "./powerclick";
import PowerSlide from "./powerslide";



// class App extends Component{

    
//     render(){
     
//         return <div>
//                   <h2>Application Component</h2>
//                   <Powerclick/>
//                   <Powerslide/>
//                 </div>
        
//      }
// };
class App extends Component{
    render(){
        return <div>
                    <h2>Application Component</h2>
                    <PowerClick city="Bangalore" title="Power Click"/>
                    <PowerSlide city="Mangalore" title="Power Slide"/>
                </div>
    }
}

export default App;

