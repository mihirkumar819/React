import React, { Component } from "react";

class ChildComp extends Component{
    elm = React.createRef();
    render(){
        return <div>
            <h1>Power sent from Parent:{this.props.power}</h1>
            <input type="text" onChange={(evt)=>this.props.changeTitle(evt.target.value)}></input>
            {/* <input type="text" onBlur={(evt)=> this.props.changeTitle(evt.target.value) }/>
            <input ref={this.elm} type="text" onBlur={()=> this.props.changeTitle(this.elm.current.value) }/>
            <input type="text" onBlur={(evt)=> this.setState({ tempmessage : evt.target.value}) } />
            <button onClick={()=> this.props.changeTitle(this.state.tempmessage)}>change parent title</button> */}
        </div>
    }
}
export default ChildComp;
