import {Component} from 'react';
let WithPower=(OriginalComp)=>{
    return class TempComp extends Component{
        state = {
            power : 0
       }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
     render(){
            return <OriginalComp power={this.state.power} increasePower={this.increasePower}></OriginalComp>
        }
    }
}

    export default WithPower;