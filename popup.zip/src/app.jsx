 
import { Component } from "react";
import PopUp from "./component/popupcomponent";
 
class App extends Component{
    state={
        title:"Welcome to your life",
        showpopup:false
    }
    togglePopup=()=>{
        this.Setstate({
            showpopup:!this.state.showpopup
        })
    }
    render(){
        return <div>
            <h1>App Component</h1>
                    <h1>{this.state.title}</h1>
                    {this.state.showpopup ? <PopUp>
                     <div>
                    <h2>{this.state.title}</h2>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Temporibus quis earum molestias. Quisquam itaque perspiciatis repellat recusandae rerum asperiores veniam aut, esse tempora omnis nam, modi nemo doloribus deserunt fuga.
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam nemo, eaque nisi rerum quos error provident quas expedita esse, minus animi quod, amet aut necessitatibus? Fuga porro quisquam vitae doloremque.
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam amet iure laudantium, quia, cupiditate voluptatum magni, blanditiis autem perspiciatis consequatur laborum quae. Dolores veritatis, temporibus sequi assumenda eveniet aut quasi!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime pariatur eveniet sed reprehenderit, ab enim exercitationem earum quisquam voluptatum atque dicta, natus eos quas quaerat doloribus, explicabo iure culpa aliquid.
                    </p>
                    <button onClick={this.togglePopup}>Hide pop-Up Windows</button>
                    <button onClick={this.changeTitle}>ChangeTitle</button>  
                    </div>
                    </PopUp>: <button onClick={this.togglePopup}>Show PopUp windows</button>
           
            
                     } </div>
            
    };
}

 
export default App;