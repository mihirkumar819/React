import { Component } from "react";
import GridComp from "./component/gridcomponent";
 
class App extends Component{
    state={
        users:[]
    }
  
    render(){
        return <div>
            <h1>User List</h1>
            <GridComp/>
        </div>
    }
}
 
export default App;
 