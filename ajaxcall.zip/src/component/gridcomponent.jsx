import { Component } from "react";
import axios from "axios";
class GridComp extends Component{
   state={
    users:[]
   }
   loadData=()=>{
    axios.get("https://reqres.in/api/users?page=2").then(res=>{
        this.setState({
            user:res.data.data
        }).catch(err=>console.log(err))
    })
   }
   componentDidMount(){
    this.loadData()
   }


    render(){

        return <table className="table">
            <thead>
                <tr>
                    <th scope="col">sl no</th>
                    <th scope="col">photo</th>
                    <th scope="col">First name</th>
                    <th scope="col">last name</th>



                </tr>
            </thead>
            <tbody>
                {
                    this.state.users.map((data,idx)=>{
                        return <tr key={data.id}>
                            <td>{idx+1}</td>
                            <td><img src={data.avatar} alt={data.first_name} />  </td>
                            <td>{data.first_name}</td>
                            <td>{data.last_name}</td>
                        </tr>
                    })
                }
            </tbody>
        </table>
            

    }
}
export default GridComp;