import { Component } from "react";
import WithPower from "./hoc/withpower";

class PowerSlide extends Component{
    
    render(){
        return <div style={ { border : "2px solid grey", margin : "10px", padding : "10px"} }>
                    <h3>Power Slide Component</h3>
                    <h4>Power : { this.props.power }</h4>
                    <h4>Version : { this.props.version }</h4>
                    <h4>Title : { this.props.title }</h4>
                    <h4>City : { this.props.city }</h4>
                    <button onClick={ this.props.increasePowerHandler }>Increase Power</button>
                    <button onClick={ this.props.increaseVersionHandler }>Increase Version</button>
                </div>
    }
}

export default WithPower(PowerSlide)