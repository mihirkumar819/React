import { Component } from "react";
 
class ChildComp extends Component{
     
    render(){
        return <div>
               
                </div>
    }
}
 
export default ChildComp;